from django.shortcuts import render
from django.http import HttpResponse

from HR.models import User
from .models import *

# Create your views here.
def home(request):
    return render(request,"HR/l_index.html")

def login(request):
    if request.POST:
        print("----button clickeddd")
        email=request.POST['email']
        password=request.POST['password']
        print("---------------email---",email)
        uid = User.objects.get(email = email)
        print("----uid",uid)
        print("---password----",uid.password)
        if password == uid.password:
            print("login sucessfully")
            hid = HR.objects.get(user_id = uid)
            return render(request,"HR/l_index.html")
        else: 
            print("invalid password")

    return render(request,"HR/login.html")
def l_index(request):
    return render(request,"HR/index.html")
    
def logout(request):
    return render(request,"HR/logout.html")
